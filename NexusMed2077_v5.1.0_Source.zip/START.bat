@echo off
chcp 65001 >nul
cd /d "%~dp0"
pip install -r requirements.txt -q
python run_2077.py
pause
