@echo off
chcp 65001 >nul
title NexusMed 2077 v4.1.0
cd /d "%~dp0"
echo.
echo   ================================
echo     NEXUSMED 2077 - v4.1.0
echo   ================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo   Python not found. Install from python.org
    start https://www.python.org/downloads/
    pause
    exit /b 1
)
echo   Installing dependencies ^(one time only^)...
pip install -r requirements.txt -q --disable-pip-version-check
echo   Starting...
python run_2077.py
if errorlevel 1 pause
