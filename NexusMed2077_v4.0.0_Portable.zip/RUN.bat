@echo off
chcp 65001 >nul
title NexusMed 2077 v4.0.0
echo.
echo   ================================
echo     NEXUSMED 2077 - v4.0.0
echo   ================================
echo.
echo   Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo   ERROR: Python not found!
    echo   Install Python from python.org
    pause
    exit /b 1
)
echo   Installing dependencies...
pip install -r requirements.txt -q
echo.
echo   Starting NexusMed 2077...
echo.
python run_2077.py
pause
