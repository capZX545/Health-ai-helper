@echo off
chcp 65001 >nul
title NexusMed 2077 - Web
cd /d "%~dp0"
pip install -r requirements.txt -q
python run_web.py
pause
